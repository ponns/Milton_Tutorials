function nextPage(){
	alert("Showing next page");	
}
function PreviousPage(){
	alert("Showing PreviousPage");	
}
function IndexPage(){
	alert("Showing IndexPage");	
}
function TopOfpage(){
	alert("Showing TopOfpage");	
}
